﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace nicholas.marconi._4i.rubricaWebDb.Migrations
{
    /// <inheritdoc />
    public partial class Prova : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Persona",
                table: "Persona");

            migrationBuilder.RenameTable(
                name: "Persona",
                newName: "Persone");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Persone",
                table: "Persone",
                column: "IdPersona");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Persone",
                table: "Persone");

            migrationBuilder.RenameTable(
                name: "Persone",
                newName: "Persona");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Persona",
                table: "Persona",
                column: "IdPersona");
        }
    }
}
