﻿using System.ComponentModel.DataAnnotations;

namespace nicholas.marconi._4i.rubricaWebDb.Models
{
    public class Persona
    {
        [Key] //libreria per fare decorazioni
        public int? IdPersona { get; set; }
        public string? Nome { get; set; }
        public string? Cognome { get; set; }
    }
}
