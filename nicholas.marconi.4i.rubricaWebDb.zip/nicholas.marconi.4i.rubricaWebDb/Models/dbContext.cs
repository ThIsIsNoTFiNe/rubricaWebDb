﻿using Microsoft.EntityFrameworkCore;

namespace nicholas.marconi._4i.rubricaWebDb.Models
{
    public class dbContext : DbContext
    {
        private readonly DbContextOptions? _options;
        public dbContext() { }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
                => options.UseSqlite("Data Source=Ribrica.db"); //nome file del database

        public DbSet<Persona> Persone { get; set; } //qua creo tabelle
    }
}
